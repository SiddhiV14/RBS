import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {

  f:FormGroup;
  constructor() { }

  ngOnInit(): void {
    this.f=new FormGroup({
      rating:new FormControl(''),
      review:new FormControl('')
    })
  }
  onSubmit(f:any) {
    console.log(f.rating);
    console.log(f.review);
  }

}
